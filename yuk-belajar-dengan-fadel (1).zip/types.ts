export enum GameState {
  SELECTING_SUBJECT,
  LOADING,
  PLAYING,
  PUNISHMENT,
  FINISHED,
}

export enum Subject {
  SKI = "Sejarah Kebudayaan Islam",
  AQIDAH = "Aqidah Akhlak",
  MATEMATIKA = "Matematika",
  IPAS = "IPAS",
  BAHASA_INDONESIA = "Bahasa Indonesia",
  BAHASA_INGGRIS = "Bahasa Inggris",
  PJOK = "PJOK",
  FIQIH = "Fiqih",
  QURAN_HADIST = "Al-Qur'an & Hadist",
  SENI = "Seni Budaya dan Prakarya",
  KEMUHAMMADIYAHAN = "Kemuhammadiyahan",
  BAHASA_ARAB = "Bahasa Arab",
}

export interface QuizQuestion {
  question: string;
  options: string[];
  answer: string;
}

export enum PunishmentType {
    SING = "Bernyanyi",
    QUIZ = "Kuis Tambahan",
    CONTINUE_VERSE = "Sambung Ayat"
}

export interface Punishment {
  type: PunishmentType;
  task: string;
  // quizQuestion is only present if type is QUIZ
  quizQuestion?: QuizQuestion;
}