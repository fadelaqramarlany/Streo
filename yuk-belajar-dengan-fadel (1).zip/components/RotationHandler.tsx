import React from 'react';
import RotateDeviceIcon from './icons/RotateDeviceIcon';

const RotationHandler: React.FC = () => {
  return (
    <div className="landscape-only-prompt fixed inset-0 bg-slate-900 bg-opacity-95 z-[100] flex-col items-center justify-center text-center p-4">
      <RotateDeviceIcon className="w-24 h-24 text-cyan-400 mb-6" />
      <h2 className="text-2xl font-bold mb-2">Mohon Putar Perangkat Anda</h2>
      <p className="text-slate-300 max-w-sm">
        Untuk pengalaman bermain kuis yang terbaik, silakan gunakan mode potret (tegak).
      </p>
    </div>
  );
};

export default RotationHandler;
