import React, { useState } from 'react';
import { Punishment, PunishmentType } from '../types';

interface PunishmentModalProps {
  punishment: Punishment;
  onContinue: () => void;
}

const PunishmentModal: React.FC<PunishmentModalProps> = ({ punishment, onContinue }) => {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const handleAnswerClick = (option: string) => {
    if (isAnswered) return;
    setIsAnswered(true);
    setSelectedAnswer(option);
  };

  const getButtonClass = (option: string) => {
    if (!isAnswered) {
      return 'bg-slate-700 hover:bg-cyan-600';
    }
    if (option === punishment.quizQuestion!.answer) {
      return 'bg-green-600';
    }
    if (option === selectedAnswer && option !== punishment.quizQuestion!.answer) {
      return 'bg-red-600';
    }
    return 'bg-slate-700 opacity-50';
  };

  const isQuizPunishment = punishment.type === PunishmentType.QUIZ && punishment.quizQuestion;
  const continueDisabled = isQuizPunishment && !isAnswered;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-slate-800 rounded-2xl shadow-2xl p-8 max-w-md w-full text-center transform transition-all animate-scale-in">
        <h2 className="text-2xl font-bold text-red-500 mb-2">Jawaban Salah!</h2>
        <h3 className="text-xl font-semibold text-yellow-400 mb-4">Hukuman: {punishment.type}</h3>

        {!isQuizPunishment ? (
          <div className="bg-slate-900 p-6 rounded-lg mb-6 min-h-[120px] flex items-center justify-center">
            <p className="text-lg text-white">{punishment.task}</p>
          </div>
        ) : (
          <div className="text-left mb-6">
            <div className="text-center bg-slate-900 p-4 rounded-lg mb-4 min-h-[90px] flex items-center justify-center">
              <p className="font-semibold text-lg">{punishment.quizQuestion.question}</p>
            </div>
            <div className="space-y-3">
              {punishment.quizQuestion.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => handleAnswerClick(opt)}
                  disabled={isAnswered}
                  className={`w-full p-3 text-left rounded-md font-medium transition-colors duration-200 ${getButtonClass(opt)}`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={onContinue}
          disabled={continueDisabled}
          className={`bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-6 rounded-lg transition-all w-full ${continueDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          Lanjutkan Kuis
        </button>
      </div>
    </div>
  );
};

export default PunishmentModal;
