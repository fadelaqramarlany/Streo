
import React from 'react';

interface TimerProps {
  timeLeft: number;
  duration: number;
}

const Timer: React.FC<TimerProps> = ({ timeLeft, duration }) => {
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const progress = (timeLeft / duration) * circumference;

  const getStrokeColor = () => {
    if (timeLeft <= 10) return 'stroke-red-500';
    if (timeLeft <= 30) return 'stroke-yellow-400';
    return 'stroke-green-500';
  };

  return (
    <div className="relative w-24 h-24">
      <svg className="w-full h-full" viewBox="0 0 120 120">
        <circle
          className="stroke-slate-700"
          strokeWidth="10"
          fill="transparent"
          r={radius}
          cx="60"
          cy="60"
        />
        <circle
          className={`transform -rotate-90 origin-center transition-all duration-1000 ease-linear ${getStrokeColor()}`}
          strokeWidth="10"
          strokeDasharray={circumference}
          strokeDashoffset={circumference - progress}
          strokeLinecap="round"
          fill="transparent"
          r={radius}
          cx="60"
          cy="60"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-2xl font-bold">
        {timeLeft}
      </span>
    </div>
  );
};

export default Timer;
