import React from 'react';
import { Subject } from '../types';

interface SubjectSelectorProps {
  onSelectSubject: (subject: Subject) => void;
}

const subjects = Object.values(Subject);

const SubjectSelector: React.FC<SubjectSelectorProps> = ({ onSelectSubject }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-slate-900">
      <div className="text-center mb-10">
        <div className="w-24 h-24 bg-cyan-500 rounded-full flex items-center justify-center mb-6 shadow-lg mx-auto">
            <span className="text-slate-900 text-6xl font-bold select-none">F</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-cyan-400">Yuk belajar dengan fadel</h1>
        <p className="text-slate-400 mt-2">Pilih mata pelajaran untuk memulai petualangan belajarmu!</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6 w-full max-w-2xl">
        {subjects.map((subject) => (
          <button
            key={subject}
            onClick={() => onSelectSubject(subject)}
            className="bg-slate-800 p-6 rounded-lg shadow-lg hover:bg-slate-700 hover:shadow-cyan-500/50 transform hover:-translate-y-1 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-cyan-400"
          >
            <span className="text-lg font-semibold text-white text-center">{subject}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default SubjectSelector;