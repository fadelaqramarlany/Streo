import React, { useState, useEffect, useCallback } from 'react';
import { QuizQuestion } from '../types';
import Timer from './Timer';

interface QuizProps {
  questions: QuizQuestion[];
  onQuizComplete: (score: number) => void;
  onIncorrectAnswer: () => void;
  onGoBack: () => void;
}

const Quiz: React.FC<QuizProps> = ({ questions, onQuizComplete, onIncorrectAnswer, onGoBack }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);

  const currentQuestion = questions[currentQuestionIndex];
  
  const handleNextQuestion = useCallback(() => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
      setTimeLeft(60);
    } else {
      onQuizComplete(score);
    }
  }, [currentQuestionIndex, questions.length, onQuizComplete, score]);

  useEffect(() => {
    if (isAnswered) {
      const timer = setTimeout(() => {
        handleNextQuestion();
      }, 2000);
      return () => clearTimeout(timer);
    }

    if (timeLeft > 0 && !isAnswered) {
      const timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && !isAnswered) {
      setIsAnswered(true);
      setSelectedAnswer(null); // Timeout is an incorrect answer
      onIncorrectAnswer();
    }
  }, [timeLeft, isAnswered, onIncorrectAnswer, handleNextQuestion]);

  const handleAnswerClick = (option: string) => {
    if (isAnswered) return;

    setIsAnswered(true);
    setSelectedAnswer(option);
    
    if (option === currentQuestion.answer) {
      setScore(prev => prev + 1);
    } else {
      onIncorrectAnswer();
    }
  };

  const getButtonClass = (option: string) => {
    if (!isAnswered) {
      return 'bg-slate-700 hover:bg-cyan-600';
    }
    if (option === currentQuestion.answer) {
      return 'bg-green-600';
    }
    if (option === selectedAnswer && option !== currentQuestion.answer) {
      return 'bg-red-600';
    }
    return 'bg-slate-700 opacity-50';
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 w-full max-w-3xl mx-auto">
      <div className="w-full bg-slate-800 rounded-2xl shadow-2xl p-6 md:p-8">
        <div className="flex justify-between items-center mb-6">
           <div className="w-1/3">
            <button onClick={onGoBack} title="Kembali ke Dashboard" className="text-slate-400 hover:text-white transition-colors duration-200 flex items-center gap-1 p-2 rounded-lg -ml-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              <span className="font-semibold text-sm hidden md:inline">Kembali</span>
            </button>
          </div>

          <div className="w-1/3 flex justify-center">
              <Timer timeLeft={timeLeft} duration={60} />
          </div>

          <div className="w-1/3 text-right">
              <div className="text-lg font-bold text-cyan-400">Skor: {score}</div>
              <div className="text-sm text-slate-300">
                Soal {currentQuestionIndex + 1}/{questions.length}
              </div>
          </div>
        </div>
        
        <div className="text-center bg-slate-900 p-4 rounded-lg mb-6 min-h-[100px] flex items-center justify-center">
            <p className="text-xl md:text-2xl font-medium">{currentQuestion.question}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerClick(option)}
              disabled={isAnswered}
              className={`w-full p-4 text-lg rounded-lg font-semibold transition-all duration-300 ${getButtonClass(option)}`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Quiz;