import React from 'react';

const RotateDeviceIcon: React.FC<{ className?: string }> = ({ className = "w-16 h-16" }) => {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M16.88 2.12001C16.88 2.12001 16.94 2.84001 16.29 3.49001C15.64 4.14001 14.92 4.12001 14.92 4.12001L10.02 4.13001C8.04 4.13001 6.44 5.73001 6.44 7.71001V16.29C6.44 18.27 8.04 19.87 10.02 19.87H13.98C15.96 19.87 17.56 18.27 17.56 16.29V11.02" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M19.33 5.5C20.86 6.63 21.91 8.22 22 10.04" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M4.67004 18.5C3.14004 17.37 2.09004 15.78 2.00004 13.96" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M10.83 2.11999L12.44 3.72999L10.83 5.33999" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
};

export default RotateDeviceIcon;
