import React from 'react';
import { Subject } from '../types';

interface ResultsProps {
  score: number;
  totalQuestions: number;
  subject: Subject;
  onRestart: () => void;
  onSelectNewSubject: () => void;
}

const Results: React.FC<ResultsProps> = ({ score, totalQuestions, subject, onRestart, onSelectNewSubject }) => {
  const percentage = Math.round((score / totalQuestions) * 100);
  const getFeedbackMessage = () => {
    if (percentage >= 80) return "Luar Biasa! Kamu Hebat!";
    if (percentage >= 60) return "Bagus! Terus Tingkatkan!";
    if (percentage >= 40) return "Cukup Baik, Belajar Lagi ya!";
    return "Jangan Menyerah, Coba Lagi!";
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="bg-slate-800 rounded-2xl shadow-2xl p-8 max-w-md w-full text-center transform transition-all animate-scale-in">
        <h2 className="text-3xl font-bold text-cyan-400 mb-2">Kuis Selesai!</h2>
        <p className="text-slate-400 mb-4">Mata Pelajaran: {subject}</p>

        <div className="my-8">
            <p className="text-lg text-slate-300">Skor Akhir Kamu</p>
            <p className="text-6xl font-bold my-2 text-white">{score} <span className="text-3xl text-slate-400">/ {totalQuestions}</span></p>
            <p className="text-2xl font-semibold text-yellow-400">{getFeedbackMessage()}</p>
        </div>

        <div className="flex flex-col space-y-4">
            <button
                onClick={onRestart}
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
            >
                Coba Lagi ({subject})
            </button>
            <button
                onClick={onSelectNewSubject}
                className="bg-slate-600 hover:bg-slate-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
            >
                Kembali ke Dashboard
            </button>
        </div>
      </div>
    </div>
  );
};

export default Results;