import React, { useState, useCallback } from 'react';
import { GameState, Subject, QuizQuestion, Punishment, PunishmentType } from './types';
import { generateQuizQuestions, generatePunishment } from './services/geminiService';
import SubjectSelector from './components/SubjectSelector';
import Quiz from './components/Quiz';
import PunishmentModal from './components/PunishmentModal';
import Results from './components/Results';
import LoadingIcon from './components/icons/LoadingIcon';
import RotationHandler from './components/RotationHandler';

const TOTAL_QUESTIONS = 10;

function App() {
  const [gameState, setGameState] = useState<GameState>(GameState.SELECTING_SUBJECT);
  const [subject, setSubject] = useState<Subject | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [score, setScore] = useState(0);
  const [punishment, setPunishment] = useState<Punishment | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startQuiz = useCallback(async (selectedSubject: Subject) => {
    setSubject(selectedSubject);
    setGameState(GameState.LOADING);
    setError(null);
    try {
      const fetchedQuestions = await generateQuizQuestions(selectedSubject, TOTAL_QUESTIONS);
      setQuestions(fetchedQuestions);
      setScore(0);
      setGameState(GameState.PLAYING);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Terjadi kesalahan tidak diketahui.");
      setGameState(GameState.SELECTING_SUBJECT); // Go back to selection on error
    }
  }, []);

  const handleIncorrectAnswer = useCallback(async () => {
    if (!subject) return;

    // Temporarily go to loading state while fetching punishment
    setGameState(GameState.LOADING);
    
    const punishmentTypes = [PunishmentType.SING, PunishmentType.QUIZ, PunishmentType.CONTINUE_VERSE];
    const randomType = punishmentTypes[Math.floor(Math.random() * punishmentTypes.length)];
    
    const generatedPunishment = await generatePunishment(randomType, subject);
    
    setPunishment(generatedPunishment);
    setGameState(GameState.PUNISHMENT);
  }, [subject]);

  const handleContinueFromPunishment = () => {
    setPunishment(null);
    setGameState(GameState.PLAYING);
  };

  const handleQuizComplete = (finalScore: number) => {
    setScore(finalScore);
    setGameState(GameState.FINISHED);
  };
  
  const handleRestart = () => {
    if (subject) {
      startQuiz(subject);
    }
  };

  const handleSelectNewSubject = () => {
    setSubject(null);
    setQuestions([]);
    setScore(0);
    setError(null);
    setGameState(GameState.SELECTING_SUBJECT);
  };

  const renderContent = () => {
    if (gameState === GameState.LOADING) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen text-cyan-400">
          <LoadingIcon className="w-16 h-16" />
          <p className="mt-4 text-xl animate-pulse">
            {punishment ? "Menyiapkan hukuman..." : "Sedang menyiapkan soal..."}
          </p>
        </div>
      );
    }
    
    if (gameState === GameState.PUNISHMENT && punishment) {
      // Keep Quiz component rendered in the background but handle punishment logic
      // This is a simplification; a better way might involve routing or more complex state.
      // But for this case, rendering the modal on top is fine.
       return (
        <>
            {questions.length > 0 && <Quiz questions={questions} onQuizComplete={() => {}} onIncorrectAnswer={() => {}} onGoBack={handleSelectNewSubject} />}
            <PunishmentModal punishment={punishment} onContinue={handleContinueFromPunishment} />
        </>
       );
    }

    switch (gameState) {
      case GameState.SELECTING_SUBJECT:
        return (
            <div>
                 {error && <div className="p-4 bg-red-800 text-white text-center fixed top-0 left-0 right-0">{error}</div>}
                 <SubjectSelector onSelectSubject={startQuiz} />
            </div>
        );
      case GameState.PLAYING:
        return <Quiz questions={questions} onQuizComplete={handleQuizComplete} onIncorrectAnswer={handleIncorrectAnswer} onGoBack={handleSelectNewSubject} />;
      case GameState.FINISHED:
        return <Results score={score} totalQuestions={TOTAL_QUESTIONS} subject={subject!} onRestart={handleRestart} onSelectNewSubject={handleSelectNewSubject} />;
      default:
        return <SubjectSelector onSelectSubject={startQuiz} />;
    }
  };

  return (
    <main className="font-sans">
      <style>{`
        .animate-scale-in {
          animation: scale-in 0.3s cubic-bezier(0.250, 0.460, 0.450, 0.940) both;
        }
        @keyframes scale-in {
          0% {
            transform: scale(0.9);
            opacity: 0;
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }
        .landscape-only-prompt {
          display: none;
        }

        @media screen and (max-width: 768px) and (orientation: landscape) {
          .landscape-only-prompt {
            display: flex;
          }
        }
      `}</style>
      <RotationHandler />
      {renderContent()}
    </main>
  );
}

export default App;