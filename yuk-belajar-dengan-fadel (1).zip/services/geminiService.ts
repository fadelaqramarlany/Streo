
import { GoogleGenAI, Type } from "@google/genai";
import { QuizQuestion, Punishment, PunishmentType, Subject } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const quizQuestionSchema = {
  type: Type.OBJECT,
  properties: {
    question: { type: Type.STRING },
    options: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    answer: { type: Type.STRING },
  },
  required: ['question', 'options', 'answer'],
};

const punishmentTaskSchema = {
    type: Type.OBJECT,
    properties: {
        task: { type: Type.STRING }
    },
    required: ['task']
};

export async function generateQuizQuestions(subject: Subject, count: number): Promise<QuizQuestion[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Buatkan ${count} soal kuis pilihan ganda untuk siswa kelas 6 SD di Indonesia dengan mata pelajaran "${subject}". Setiap soal harus memiliki 4 pilihan jawaban dan satu jawaban yang benar. Pastikan tingkat kesulitannya sesuai.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: quizQuestionSchema,
        },
      },
    });
    const jsonString = response.text.trim();
    const questions = JSON.parse(jsonString);
    // Basic validation
    if (!Array.isArray(questions) || questions.length === 0) {
        throw new Error("Generated data is not a valid question array.");
    }
    return questions;
  } catch (error) {
    console.error("Error generating quiz questions:", error);
    throw new Error("Gagal membuat soal kuis. Coba lagi nanti.");
  }
}


export async function generatePunishment(type: PunishmentType, subject: Subject): Promise<Punishment> {
    try {
        if (type === PunishmentType.QUIZ) {
            const extraQuestion = await generateQuizQuestions(subject, 1);
            return {
                type: PunishmentType.QUIZ,
                task: "Jawab pertanyaan tambahan ini!",
                quizQuestion: extraQuestion[0]
            };
        }

        let prompt = "";
        if (type === PunishmentType.SING) {
            prompt = "Berikan satu tugas menyanyi yang seru untuk anak kelas 6 SD, bisa lagu nasional atau lagu daerah Indonesia. Berikan judul lagunya.";
        } else { // CONTINUE_VERSE
            prompt = "Berikan awalan dari sebuah ayat pendek yang populer dari Juz 30 (An-Naba sampai An-Nas) dan minta untuk melanjutkannya. Formatnya: 'Lanjutkan ayat berikut: [AWALAN AYAT]...'";
        }

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: punishmentTaskSchema,
            }
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString) as { task: string };

        return { type, task: result.task };

    } catch (error) {
        console.error(`Error generating ${type} punishment:`, error);
        // Fallback punishment
        return {
            type,
            task: "Ucapkan Pancasila dengan lantang!"
        };
    }
}
